<?php
/*
Plugin Name: 数据库优化
Plugin URI: http://wpjam.net/item/wpjam-basic/
Description: 优化你博客中的所有数据表
Version: 1.0
*/