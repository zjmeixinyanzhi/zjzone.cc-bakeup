<?php
/*
Plugin Name: Post Type Switcher
Plugin URI: http://wpjam.net/item/wpjam-basic/
Description: 日志类型转换器。
Version: 1.0
*/