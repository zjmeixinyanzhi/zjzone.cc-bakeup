<?php

if(!function_exists('wpjam_option_page')){
	include($WPJAM_TOC_PLUGIN_DIR.'include/wpjam-setting-api.php');
}

add_action('save_post','wpjam_delete_toc_cache');
function wpjam_delete_toc_cache($post_id){

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
		return;

	wp_cache_delete($post_id,'wpjam-toc'); // 删除 TOC 缓存

	if(wpjam_toc_get_setting('individual') && isset($_POST['wpjam_toc_post_meta_nonce'])){
		if ( !wp_verify_nonce( $_POST['wpjam_toc_post_meta_nonce'], 'wpjam_toc' ) ) 
		return;

		if ( !current_user_can( 'edit_post', $post_id ) ) 
			return;

		$toc_hidden	= isset($_POST['toc_hidden'])?1:0;

		if($toc_hidden){
			update_post_meta($post_id, 'toc_hidden', 1);
		}else{
			if(get_post_meta($post_id, 'toc_hidden',true)){
				delete_post_meta($post_id, 'toc_hidden');
			}
		}

		$toc_depth	= isset($_POST['toc_depth'])?$_POST['toc_depth']:wpjam_toc_get_setting('depth');

		if($toc_depth){
			if($toc_depth == wpjam_toc_get_setting('depth')){
				delete_post_meta($post_id, 'toc_depth');
			}else{
				update_post_meta($post_id, 'toc_depth', $toc_depth);			
			}

		}
	}
}

add_action( 'add_meta_boxes', 'wpjam_toc_add_meta_box' );
function wpjam_toc_add_meta_box() {
	if(wpjam_toc_get_setting('individual')){
		add_meta_box( 'wpjam-toc-setting', '文章目录设置', 'wpjam_toc_custom_meta_box', null, 'side' );
	}
}

function wpjam_toc_custom_meta_box( $post ) {

	$toc_hidden = get_post_meta($post->ID,'toc_hidden',true);
	$toc_hidden_checked = ($toc_hidden)?'checked':'';

	$toc_depth = get_post_meta($post->ID,'toc_depth',true);
	if(!$toc_depth) $toc_depth = wpjam_toc_get_setting('depth');

	$form_fields = array(
		'toc_hidden'	=> array('title'=>'',					'type'=>'checkbox',		'value'=>1,				'checked'=>$toc_hidden_checked,	'description'=>'隐藏文章目录'),
		'toc_depth'		=> array('title'=>'显示到第几级目录：',	'type'=>'select',		'value'=>$toc_depth,	'options'=>array('1'=>'h1','2'=>'h2','3'=>'h3','4'=>'h4','5'=>'h5','6'=>'h6',),	'description'=>'')
	);

	 wpjam_form_fields($form_fields, 'list');
	 wp_nonce_field('wpjam_toc','wpjam_toc_post_meta_nonce');
}

add_filter('wpjam_pages', 'wpjam_toc_admin_pages');
function wpjam_toc_admin_pages($wpjam_pages){

	$wpjam_pages['options']['subs']['wpjam-toc']	= array(
		'menu_title'	=> '文章目录',		
		'function'		=> 'option',
	);

	return $wpjam_pages;
}



add_filter('wpjam_settings', 'wpjam_toc_settings');
function wpjam_toc_settings($wpjam_settings){
	$wpjam_settings['wpjam-toc'] 	= array('sections'=>wpjam_toc_get_option_labels());
	return $wpjam_settings;
}

function wpjam_toc_setting_page() {
	$labels = wpjam_toc_get_option_labels();
	wpjam_option_page($labels, 'WPJAM 文章目录');
}

function wpjam_toc_get_option_labels(){

    $fields = array(
		'auto'		=> array('title'=>'自动插入脚本',		'type'=>'checkbox', 'description'=>'自动插入 JavaScript 和 CSS 代码。'),
		'script'	=> array('title'=>'JavaScript 代码',	'type'=>'textarea',	'rows'=>6,	'description'=>'如果你没有选择自动插入脚本，可以将下面的 JavaScript 代码复制你主题的 JavaScript 文件中。'),
		'css'		=> array('title'=>'CSS 代码',		'type'=>'textarea',	'rows'=>6,	'description'=>'根据你的主题对下面的 CSS 代码做适当的修改。<br />如果你没有选择自动插入脚本，可以将下面的 CSS 代码复制你主题的 CSS 文件中。'),
    	'depth'		=> array('title'=>'目录显示到第几级',	'type'=>'select',	'options'=>array( '1'=>'h1','2'=>'h2','3'=>'h3','4'=>'h4','5'=>'h5','6'=>'h6',),	'description'=>''),
    	'individual'=> array('title'=>'文章编辑页面选项',	'type'=>'checkbox',	'description'=>'允许在每篇文章编辑页面单独设置是否显示文章目录以及显示到第几级。'),
    );

    $fields['copyright'] = array('title'=>'版权信息',		'type'=>'checkbox', 'description'=>'在文章目录下面显示版权信息。');

    return array(
    	'wpjam-toc'			=> array('title'=>'', 'fields'=>$fields,	'callback'=>'' ),
	);
}

add_filter('wpjam-toc_defaults', 'wpjam_toc_get_default_option');
function wpjam_toc_get_default_option(){
	return array(
		'auto'		=> '1',
		'copyright'	=> '1',
		'individual'=> '1',
		'depth'		=> '6',
		'script'	=> 
"jQuery(document).ready(function(){
	jQuery('#toc span').on('click',function(){
	    if(jQuery('#toc span').html() == '[显示]'){
	        jQuery('#toc span').html('[隐藏]');
	    }else{
	        jQuery('#toc span').html('[显示]');
	    }
	    jQuery('#toc ul').toggle();
	    jQuery('#toc small').toggle();
	});
});
",
		'css'		=> 
'#toc {
	float:right;
	max-width:240px;
	min-width:120px;
	padding:6px;
	margin:0 0 20px 20px;
	border:1px solid #EDF3DE;
	background:white;
	border-radius:6px;
}
#toc p {
	margin:0 4px;
}
#toc strong {
	border-bottom:1px solid #EDF3DE;
	display:block;
}
#toc span {
	display:block;
	margin:4px 0;
    cursor:pointer;
}
#toc ul{
	margin-bottom:0;
}
#toc li{
	margin:2px 0;
}
#toc small {
	float:right;
}',
	);
}

function wpjam_toc_validate( $wpjam_toc ) {
	$current = get_option( 'wpjam-toc' );

	foreach (array('auto','individual') as $key ) {
		if(empty($wpjam_toc[$key])){ //checkbox 未选，Post 的时候 $_POST 中是没有的，
			$wpjam_toc[$key] = 0;
		}
	}

	if(empty($wpjam_toc['copyright'])){ //checkbox 未选，Post 的时候 $_POST 中是没有的，
		$wpjam_toc['copyright'] = 0;
	}

	if(empty($wpjam_toc['individual'])){ //checkbox 未选，Post 的时候 $_POST 中是没有的，
		$wpjam_toc['individual'] = 0;
	}

	return $wpjam_toc;
}

function wpjam_toc_get_setting($setting_name){
	$option = wpjam_toc_get_option();
	return wpjam_get_setting($option, $setting_name);
}

function wpjam_toc_get_option(){
	$defaults = wpjam_toc_get_default_option();
	return wpjam_get_option('wpjam-toc',$defaults);
}