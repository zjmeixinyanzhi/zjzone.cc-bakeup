jQuery(function($) {
	$.colorpicker.regional['fr'] = {
		ok:				'OK',
		cancel:			'Annuler',
		none:			'Aucune couleur',
		button:			'Couleur',
		title:			'Choisir une couleur',
		transparent:	'Transparent',
		hsvH:			'T',
		hsvS:			'S',
		hsvV:			'V',
		rgbR:			'R',
		rgbG:			'V',
		rgbB:			'B',
		labL:			'L',
		labA:			'a',
		labB:			'b',
		hslH:			'T',
		hslS:			'S',
		hslL:			'L',
		cmykC:			'C',
		cmykM:			'M',
		cmykY:			'J',
		cmykK:			'N',
		alphaA:			'A'
	};
});
