<?php
/*
Plugin Name: 定时作业
Plugin URI: http://wpjam.net/item/wpjam-basic/
Description: 在 WordPress 后台管理和查看定时作业。
Version: 1.0
*/