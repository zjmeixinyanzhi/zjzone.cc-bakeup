=== Plugin Name ===
Contributors: 偶爱偶家
Donate link: none
Tags: slug, translate, translation, google translate, english, pinyin, 缩略名, 拼音, 翻译, 英语
Requires at least: 2.1
Tested up to: 2.5
Stable tag: 1.5

wp slug will set slug by translate title to english with google translate or pinyin.

== Description ==

wp slug will set slug by translate title to english with google translate or pinyin. 设置wordpress slug 通过google translate翻译标题到英语, 在google translate 翻译失败时转换成拼音.

<h3>Admin Features</h3>
<ul>
<li>None</li>
</ul>

<h3>User Features</h3>
<ul>
<li>None</li>
</ul>

<h3>Plugin Features</h3>

== Installation ==

1. Just unzip
2. upload the "wp-slug" folder to your '/wp-content/plugins/' directory
3. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Have some FAQ now? =

no question.


== Languages == 

no language.


== Usage ==

just active.

== Screenshots ==
none